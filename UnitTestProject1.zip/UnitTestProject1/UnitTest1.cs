﻿using System;
using System.Threading;
using System.Drawing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.Events;
namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            using (var driver = new ChromeDriver())
            {
                driver.Manage().Window.Maximize();
                driver.Navigate().GoToUrl("http://signup.insly.com");

                // Find Singup and Text
                driver.FindElementByName("broker_name").SendKeys("Suur Puncho");
                // By default it takes country
               /* IWebElement Country = (IWebElement)driver.FindElementByName("broker_address_country");
                SelectElement elem = new SelectElement(Country);
                elem.SelectByIndex(2);
                */
                IWebElement broker_tag = (IWebElement)driver.FindElementByName("broker_tag");
                broker_tag.Click();
                Thread.Sleep(10000);
            
                IWebElement comp_prof = (IWebElement)driver.FindElementByName("prop_company_profile");
                SelectElement elem_com = new SelectElement(comp_prof);
                elem_com.SelectByIndex(2);
               // Thread.Sleep(10000);
                IWebElement num_emp = (IWebElement)driver.FindElementByName("prop_company_no_employees");
                SelectElement elem_num = new SelectElement(num_emp);
                elem_num.SelectByIndex(2);
                //Thread.Sleep(10000);
                IWebElement num_desc = (IWebElement)driver.FindElementByName("prop_company_person_description");
                SelectElement elem_desc = new SelectElement(num_desc);
                elem_desc.SelectByIndex(2);

               

                //Go to Admin Section and Fill all the details
                driver.FindElementByName("broker_admin_email").SendKeys("suurpuncho@gmail.com");
                driver.FindElementByName("broker_admin_name").SendKeys("Rohcvxcv dsf");

                IWebElement broker_pass = (IWebElement)driver.FindElementByLinkText("suggest a secure password");
                broker_pass.Click();
                Thread.Sleep(5000);
                driver.SwitchTo().ActiveElement().SendKeys(Keys.Enter);
              
                driver.FindElementByName("broker_admin_phone").SendKeys("9953675441");

                IWebElement termCond = (IWebElement)driver.FindElementByLinkText("terms and conditions");
                termCond.Click();
                Thread.Sleep(5000);
                driver.SwitchTo().ActiveElement().SendKeys(Keys.Enter);
               

                IJavaScriptExecutor jse = (IJavaScriptExecutor)driver;
                IWebElement termConds = (IWebElement)driver.FindElementByLinkText("privacy policy");
                termConds.Click();
                Thread.Sleep(5000);

                IWebElement Pripol = (IWebElement)driver.FindElementById("document-content");
                // Move the mouse over the scroll bar and scroll down the page              
                IAction scrollDown = new Actions(driver)
               .MoveToElement(Pripol,850,20)// position mouse over scrollbar
                .ClickAndHold()
                .MoveByOffset(0, 500) // scroll down
                .Release()
                .Build();

                scrollDown.Perform();
                driver.SwitchTo().ActiveElement().SendKeys(Keys.Escape);
                
                jse.ExecuteScript("document.getElementById('agree_termsandconditions').click();");
                jse.ExecuteScript("document.getElementById('agree_privacypolicy').click();");
                jse.ExecuteScript("document.getElementById('agree_data_processing').click();");

                IWebElement ell = (IWebElement)driver.FindElementByName("submit_save");
                ell.Submit();

                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
                wait.Until(ExpectedConditions.UrlContains("dashboard"));

                //Close driver
                driver.Quit();
            }
        }
    }
}
